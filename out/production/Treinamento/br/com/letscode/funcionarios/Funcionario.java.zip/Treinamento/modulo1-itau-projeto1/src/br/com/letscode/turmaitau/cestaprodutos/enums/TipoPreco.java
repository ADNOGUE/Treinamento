package br.com.letscode.turmaitau.cestaprodutos.enums;

public enum TipoPreco {

    CARO,
    BARATO

}
