package br.com.letscode.turmaitau.operacoes;

public class Subtrair {

    public void realizarOperacao(double numero1, double numero2) {

        System.out.printf("Resultado: %.2f - %.2f = %.2f %s ", numero1, numero2, (numero1 - numero2), "!");

    }

}
