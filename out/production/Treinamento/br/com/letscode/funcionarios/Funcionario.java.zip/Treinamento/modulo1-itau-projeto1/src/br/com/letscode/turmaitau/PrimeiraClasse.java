package br.com.letscode.turmaitau;


public class PrimeiraClasse {

    //esse é um metodo de inicializaçao
    public static void main(String[] args) {

        //TODO : preciso rever essa parte
        byte conversaoAsc = 'b';

        // CAST => (char) conversaoAsc;
        /*
            isso é um comentario!!
         */
        System.out.println("byte = " + conversaoAsc);

    }

}
